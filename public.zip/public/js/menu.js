﻿function toggleMenu() {
    const menu = document.getElementById("menuPrincipal");
    menu.classList.toggle("mostrar");
}
